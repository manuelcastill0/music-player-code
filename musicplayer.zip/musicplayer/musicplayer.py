import vlc

songs = {
    "Song 1": "Love Me Again.mp3",
    "Song 2": "Never Gonna Give You Up.mp3",
    "Song 3": "Around The World.mp3",
    "Song 4": "Feet Don't Fail Me Now.mp3",
    "Song 5": "Wavin' Flag.mp3",
}

player = vlc.MediaPlayer()
current_song = None

while True:
    song_choice = input("choose a song: Song 1, Song 2, Song 3, Song 4, Song 5) or type 'exit' to quit: ")

    if song_choice == "exit":
        if current_song:
            current_song.stop()
        break

    elif song_choice in songs:
        if current_song:
            current_song.stop()
        current_song = vlc.MediaPlayer(songs[song_choice])
        current_song.play()

    else:
        print("sorry, not able to play the song.")
